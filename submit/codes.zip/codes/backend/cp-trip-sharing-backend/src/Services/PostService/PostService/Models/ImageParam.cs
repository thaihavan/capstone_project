﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace PostService.Models
{
    public class ImageParam
    {
        public string Image { get; set; }

        public string Type { get; set; }
    }
}
