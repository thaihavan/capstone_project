﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace UserServices.Models
{
    public class IncreasingCP
    {
        public string UserId { get; set; }
        
        public int Point { get; set; }
    }
}
