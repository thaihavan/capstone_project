﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace IdentityProvider.Helpers
{
    public class PubsubSettings
    {
        public string TopicId { get; set; }
        public string ProjectId { get; set; }
    }
}
