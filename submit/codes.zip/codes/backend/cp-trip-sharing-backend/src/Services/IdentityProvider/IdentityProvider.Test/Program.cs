﻿using System;

namespace IdentityProvider.Test
{
    class Program
    {
        static void Mai1(string[] args)
        {
           
        }
    }
}
