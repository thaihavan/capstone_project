import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-only-for-home-page',
  templateUrl: './only-for-home-page.component.html',
  styleUrls: ['./only-for-home-page.component.css']
})
export class OnlyForHomePageComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
