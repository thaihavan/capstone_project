export class Like {
    objectId: string;
    objectType: string;
    dateTime: Date;
    userId: string;
}
