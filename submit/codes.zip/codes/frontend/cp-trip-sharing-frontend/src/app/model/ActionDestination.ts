import { LocationMarker } from './LocationMarker';

export class ActionDestination {
    typeAction: string;
    item: LocationMarker;
}
