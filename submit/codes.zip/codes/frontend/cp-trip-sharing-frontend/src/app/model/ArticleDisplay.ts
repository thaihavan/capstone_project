export class ArticleDisplay {
    typeArticle: string;
    items: [];

    constructor() {
        this.items = [];
    }
}
