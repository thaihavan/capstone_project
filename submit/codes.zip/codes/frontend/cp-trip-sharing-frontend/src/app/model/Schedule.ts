export class Schedule {
    constructor() {
        this.title = '';
        this.content = '';
        this.day = null;
    }
    title: string;
    content: string;
    day: Date;
}
