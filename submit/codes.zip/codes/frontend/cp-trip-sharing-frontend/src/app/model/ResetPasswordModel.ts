export class ResetPasswordModel {
    NewPassword: string;
}
