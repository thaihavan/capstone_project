export class ReportType {
    id: string;
    name: string;
}
