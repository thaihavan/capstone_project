export class ChatUser {
    id: string;
    displayName: string;
    profileImage: string;
}
