export class PopupMessage {
    messageType: string;
    messageText: string;
    color: string;
    url: string;

    constructor() {

    }
}
