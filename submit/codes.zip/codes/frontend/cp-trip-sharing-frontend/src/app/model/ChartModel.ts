class ChartMiniItem {
    name: string;
    value: number;
}

export class ChartSingleModel {
    name: string;
    series: ChartMiniItem[];
}
