export interface InterestedTopic {
    topicName: string;
    urlImage: string;
}
