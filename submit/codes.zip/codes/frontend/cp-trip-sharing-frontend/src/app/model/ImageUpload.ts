export class ImageUpload {
    image: any;
    type: string;
}
