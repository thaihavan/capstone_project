export class ChangePassword {
    CurrentPassword: string;
    NewPassword: string;
}
