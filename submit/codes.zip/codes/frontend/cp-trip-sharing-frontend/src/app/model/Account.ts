export class Account {
    public userId: string;
    public email: string;
    public password: string;
    public oldPassword: string;
    public newPassword: string;
    public role: string;
    public token: string;
    public googleId: string;
    public facebookId: string;
}
