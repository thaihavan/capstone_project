export class ArticleDestinationItem {
    id: string;
    name: string;
}
