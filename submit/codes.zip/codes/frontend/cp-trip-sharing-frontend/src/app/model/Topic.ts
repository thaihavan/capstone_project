export class Topic {
    id: string;
    name: string;
    imgUrl: string;
    isActive: string;
}
