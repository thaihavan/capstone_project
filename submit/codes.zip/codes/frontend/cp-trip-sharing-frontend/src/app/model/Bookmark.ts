import { Post } from './Post';

export class Bookmark {
    public id: string;

    public userId: string;

    public postId: string;

    public post: Post;
}
