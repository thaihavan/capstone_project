export class ChatMessage {
    id: string;
    fromUserId: string;
    conversationId: string;
    content: string;
    time: Date;
}