export class StatisticsFilter {
    from: Date;
    to: Date;
}
