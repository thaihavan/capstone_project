import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-report-page-admin',
  templateUrl: './report-page-admin.component.html',
  styleUrls: ['./report-page-admin.component.css']
})
export class ReportPageAdminComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
